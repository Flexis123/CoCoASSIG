define i32 @main() {
  %1 = alloca float
  store float 5.000000e+00, float* %1
  %2 = load float, float* %1

  %3 = fmul float 2.000000e+00, 0.000000e+00
  ; CHECK: %4 = fadd float 0.000000e+00, 0.000000e+00
  %4 = fadd float %3, 0.000000e+00

  %5 = fmul float 0.000000e+00, 2.000000e+00
  ; CHECK: %6 = fadd float 0.000000e+00, 0.000000e+00
  %6 = fadd float %5, 0.000000e+00

  %7 = fmul float 2.000000e+00, 1.000000e+00
  ; CHECK: %8 = fadd float 2.000000e+00, 0.000000e+00
  %8 = fadd float %7, 0.000000e+00

  %9 = fmul float 1.000000e+00, 2.000000e+00
  ; CHECK: %10 = fadd float 2.000000e+00, 0.000000e+00
  %10 = fadd float %9, 0.000000e+00

  %11 = fmul float %2, 1.000000e+00
  ; CHECK: %12 = fadd float %2, 0.000000e+00
  %12 = fadd float %11, 0.000000e+00

  %13 = fmul float 1.000000e+00, %2
  ; CHECK: %14 = fadd float %2, 0.000000e+00
  %14 = fadd float %13, 0.000000e+00

  %15 = fmul float 2.000000e+00, -1.000000e+00
  ; CHECK: %16 = fadd float -2.000000e+00, 0.000000e+00
  %16 = fadd float %15, 0.000000e+00

  %17 = fmul float -1.000000e+00, 2.000000e+00
  ; CHECK: %18 = fadd float -2.000000e+00, 0.000000e+00
  %18 = fadd float %17, 0.000000e+00

  ; CHECK: %19 = fsub float -0.000000e+00, %2
  ; CHECK: %20 = fmul float %2, -1.000000e+00 
  %19 = fmul float %2, -1.000000e+00
  ; CHECK: %21 = fadd float %19, 0.000000e+00
  %20 = fadd float %19, 0.000000e+00

  ; CHECK: %22 = fsub float -0.000000e+00, %2
  ; CHECK: %23 = fmul float -1.000000e+00, %2 
  %21 = fmul float -1.000000e+00, %2 
  ; CHECK: %24 = fadd float %22, 0.000000e+00
  %22 = fadd float %21, 0.000000e+00

  ret i32 1
}