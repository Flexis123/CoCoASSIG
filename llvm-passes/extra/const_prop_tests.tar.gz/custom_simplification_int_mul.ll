define i32 @main() {
  %1 = alloca i32
  store i32 5, i32* %1
  %2 = load i32, i32* %1

  %3 = mul i32 %2, 0
  ; CHECK: %4 = add i32 0, 0
  %4 = add i32 %3, 0

  %5 = mul i32 0, %2
  ; CHECK: %6 = add i32 0, 0
  %6 = add i32 %5, 0

  %7 = mul i32 %2, 1
  ; CHECK: %8 = add i32 %2, 0
  %8 = add i32 %7, 0

  %9 = mul i32 1, %2
  ; CHECK: %10 = add i32 %2, 0
  %10 = add i32 %9, 0

  ret i32 %2
}
