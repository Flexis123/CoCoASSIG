; you probably do NOT need to pass this test
define i32 @main() {
entry:
  br label %a
a:
  %0 = add i32 5, 4
  %1 = icmp slt i32 %0, 10
  br i1 %1, label %b, label %c
c:
  ; CHECK: %2 = phi i32 [ 13, %a ], [ 13, %b ]
  %2 = phi i32 [ 13, %a ], [ %5, %b ]
  ; CHECK: %3 = add i32 13, 5
  %3 = add i32 %2, 5
  ; CHECK: %4 = mul i32 9, 18
  %4 = mul i32 %0, %3
  br label %d
b:
  ; CHECK: %5 = add i32 9, 4
  %5 = add i32 %0, 4
  br label %c
d:
  ; CHECK: %6 = add i32 162, 34
  %6 = add i32 %4, 34
  ; CHECK: ret i32 196
  ret i32 %6
}
