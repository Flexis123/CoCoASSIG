define i32 @main() {
  %1 = alloca i32
  store i32 5, i32* %1
  %2 = load i32, i32* %1

  ; CHECK: %3 = sub i32 0, %2
  ; CHECK-NOT: %3 = mul i32 -1, %2
  ; CHECK: %4 = mul i32 -1, %2
  %3 = mul i32 -1, %2
  ; CHECK: %5 = add i32 %3, 0
  %4 = add i32 %3, 0

  ; CHECK: %6 = sub i32 0, %2
  ; CHECK-NOT: %6 = mul i32 %2, -1
  ; CHECK: %7 = mul i32 %2, -1
  %5 = mul i32 %2, -1
  ; CHECK: %8 = add i32 %6, 0
  %6 = add i32 %5, 0

  ; CHECK: %9 = sub i32 0, %2
  ; CHECK-NOT: %9 = sdiv i32 %2, -1
  ; CHECK: %10 = sdiv i32 %2, -1
  %7 = sdiv i32 %2, -1
  ; CHECK: %11 = add i32 %9, 0
  %8 = add i32 %7, 0

  ret i32 %2
}
