define i32 @main() {
  %1 = alloca i32
  store i32 5, i32* %1
  %2 = load i32, i32* %1

  ; CHECK: %3 = shl i32 %2, 11
  ; CHECK-NOT: %3 = mul i32 %2, 2048
  ; CHECK: %4 = mul i32 %2, 2048
  %3 = mul i32 %2, 2048
  ; CHECK: %5 = add i32 %3, 0
  %4 = add i32 %3, 0

  ; CHECK: %6 = ashr i32 %2, 16
  ; CHECK-NOT: %6 = sdiv i32 %2, 65536
  ; CHECK: %7 = sdiv i32 %2, 65536
  %5 = sdiv i32 %2, 65536
  ; CHECK: %8 = add i32 %6, 0
  %6 = add i32 %5, 0

  ; CHECK: %9 = lshr i32 %2, 16
  ; CHECK-NOT: %9 = udiv i32 %2, 65536
  ; CHECK: %10 = udiv i32 %2, 65536
  %7 = udiv i32 %2, 65536
  ; CHECK: %11 = add i32 %9, 0
  %8 = add i32 %7, 0

  ; CHECK: %12 = add i32 %2, %2
  ; CHECK-NOT: %12 = mul i32 %2, 2
  ; CHECK: %13 = mul i32 %2, 2
  %9 = mul i32 %2, 2
  ; CHECK: %14 = add i32 %12, 0
  %10 = add i32 %9, 0

  ; CHECK: %15 = add i32 %2, %2
  ; CHECK-NOT: %15 = mul i32 2, %2
  ; CHECK: %16 = mul i32 2, %2
  %11 = mul i32 2, %2
  ; CHECK: %17 = add i32 %15, 0
  %12 = add i32 %11, 0

  ret i32 %2
}
