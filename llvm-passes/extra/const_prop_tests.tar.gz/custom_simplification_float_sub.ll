define i32 @main() {
  %1 = alloca float
  store float 5.000000e+00, float* %1
  %2 = load float, float* %1

  %3 = fsub float 2.000000e+00, 0.000000e+00
  ; CHECK: %4 = fadd float 2.000000e+00, 0.000000e+00
  %4 = fadd float %3, 0.000000e+00

  %5 = fsub float %2, 0.000000e+00
  ; CHECK: %6 = fadd float %2, 0.000000e+00
  %6 = fadd float %5, 0.000000e+00

  ret i32 1
}