define i32 @main() {
  %1 =  add  i32  12,  35
  %2 =  sub  i32  %1, -34
  %3 =  udiv i32  %2,   3
  %4 =  mul  i32  %3,  24
  %5 =  urem i32  %4, 136
  %6 =  sdiv i32  %5,  -4
  %7 =  srem i32  %6,  10

  ; CHECK: %1 = add i32 12, 35
  ; CHECK: %2 = sub i32 47, -34
  ; CHECK: %3 = udiv i32 81, 3
  ; CHECK: %4 = mul i32 27, 24
  ; CHECK: %5 = urem i32 648, 136
  ; CHECK: %6 = sdiv i32 104, -4
  ; CHECK: %7 = srem i32 -26, 10

  %8 =  shl  i32 428,  13
  %9 =  lshr i32  %8,   8
  %10 = ashr i32  %9,   3
  %11 = and  i32 %10, 927
  %12 = or   i32 %11,  37
  %13 = xor  i32 %12, 127

  ; CHECK: %8 = shl i32 428, 13
  ; CHECK: %9 = lshr i32 3506176, 8
  ; CHECK: %10 = ashr i32 13696, 3
  ; CHECK: %11 = and i32 1712, 927
  ; CHECK: %12 = or i32 656, 37
  ; CHECK: %13 = xor i32 693, 127

  ret i32 %13
  ; CHECK: ret i32 714
}
