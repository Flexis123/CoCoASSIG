; you probably do NOT need to pass this test
define i32 @main() {
entry:
  %0 = add i32 2, 3
  %1 = icmp slt i32 %0, 10
  br i1 %1, label %yes, label %no

yes:
  %2 = add i32 3, 1
  br label %end

no:
  %3 = add i32 2, 2
  br label %end

end:
  ; CHECK: %4 = phi i32 [ 4, %yes ], [ 4, %no ]
  %4 = phi i32 [ %2, %yes ], [ %3, %no ]
  ; CHECK: %5 = add i32 4, 0
  %5 = add i32 %4, 0
  ret i32 0
}
