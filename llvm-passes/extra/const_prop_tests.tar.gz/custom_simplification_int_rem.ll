define i32 @main() {
  %1 = alloca i32
  store i32 5, i32* %1
  %2 = load i32, i32* %1

  %3 = urem i32 %2, 1
  ; CHECK: %4 = add i32 0, 0
  %4 = add i32 %3, 0

  %5 = srem i32 %2, 1
  ; CHECK: %6 = add i32 0, 0
  %6 = add i32 %5, 0

  ret i32 %2
}
