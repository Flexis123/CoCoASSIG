define i32 @main() {
  %1 = alloca i32
  %2 = alloca i64
  store i32 5, i32* %1
  store i64 5, i64* %2
  %3 = load i32, i32* %1
  %4 = load i64, i64* %2

  %5 = shl i32 %3, 0
  ; CHECK: %6 = add i32 %3, 0
  %6 = add i32 %5, 0

  %7 = shl i32 0, %3
  ; CHECK: %8 = add i32 0, 0
  %8 = add i32 %7, 0

  %9 = shl i32 %3, 31
  ; CHECK: %10 = add i32 %9, 0
  %10 = add i32 %9, 0

  %11 = shl i32 %3, 32
  ; CHECK: %12 = add i32 0, 0
  %12 = add i32 %11, 0

  %13 = shl i64 %4, 42
  ; CHECK: %14 = add i64 %13, 0
  %14 = add i64 %13, 0

  %15 = lshr i32 %3, 0
  ; CHECK: %16 = add i32 %3, 0
  %16 = add i32 %15, 0

  %17 = lshr i32 0, %3
  ; CHECK: %18 = add i32 0, 0
  %18 = add i32 %17, 0

  %19 = lshr i32 %3, 31
  ; CHECK: %20 = add i32 %19, 0
  %20 = add i32 %19, 0

  %21 = lshr i32 %3, 32
  ; CHECK: %22 = add i32 0, 0
  %22 = add i32 %21, 0

  %23 = lshr i64 %4, 42
  ; CHECK: %24 = add i64 %23, 0
  %24 = add i64 %23, 0

  %25 = lshr i64 %4, 65
  ; CHECK: %26 = add i64 0, 0
  %26 = add i64 %25, 0

  %27 = ashr i32 %3, 0
  ; CHECK: %28 = add i32 %3, 0
  %28 = add i32 %27, 0

  %29 = ashr i32 0, %3
  ; CHECK: %30 = add i32 0, 0
  %30 = add i32 %29, 0

  %31 = ashr i32 %3, 31
  ; CHECK: %32 = add i32 %31, 0
  %32 = add i32 %31, 0

  %33 = ashr i32 %3, 32
  ; CHECK: %34 = add i32 %33, 0
  %34 = add i32 %33, 0

  %35 = ashr i64 %4, 42
  ; CHECK: %36 = add i64 %35, 0
  %36 = add i64 %35, 0

  %37 = ashr i64 %4, 65
  ; CHECK: %38 = add i64 %37, 0
  %38 = add i64 %37, 0

  ret i32 %3
}
