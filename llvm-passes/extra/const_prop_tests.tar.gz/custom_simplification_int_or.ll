define i32 @main() {
  %1 = alloca i32
  store i32 5, i32* %1
  %2 = load i32, i32* %1

  %3 = or i32 %2, 0
  ; CHECK: %4 = add i32 %2, 0
  %4 = add i32 %3, 0

  %5 = or i32 0, %2
  ; CHECK: %6 = add i32 %2, 0
  %6 = add i32 %5, 0

  %7 = or i32 %2, %2
  ; CHECK: %8 = add i32 %2, 0
  %8 = add i32 %7, 0

  %9 = or i32 %2, -1
  ; CHECK: %10 = add i32 -1, 0
  %10 = add i32 %9, 0

  %11 = or i32 -1, %2
  ; CHECK: %12 = add i32 -1, 0
  %12 = add i32 %11, 0

  ret i32 %2
}
